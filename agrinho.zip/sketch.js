let farmerX = 300;
let farmerY = 280;
let farmerSpeed = 3;

let treePositions = [
  { x: 100, y: 330 },
  { x: 200, y: 330 },
  { x: 300, y: 330 },
  { x: 400, y: 330 },
  { x: 500, y: 330 },
  { x: 630, y: 330 }
];

let apples = [];
let startTime;
let totalTime = 260; // 260 segundos = 4 minutos e 20 segundos
let gameOver = false;

function setup() {
  createCanvas(700, 400);
  spawnApple();
  startTime = millis(); // salva o momento em que o jogo começa
}

function draw() {
  background(135, 206, 235); // céu
  fill(34, 139, 34);
  rect(0, height - 50, width, 50); // chão

  // Tempo restante
  let elapsed = int((millis() - startTime) / 1000);
  let timeLeft = max(totalTime - elapsed, 0);

  // Mostra o tempo em MM:SS
  let min = nf(int(timeLeft / 60), 2);
  let sec = nf(timeLeft % 60, 2);

  fill(0);
  textSize(20);
  text(`Tempo: ${min}:${sec}`, 20, 30);

  if (timeLeft <= 0) {
    gameOver = true;
    textSize(40);
    fill(255, 0, 0);
    textAlign(CENTER);
    text("Tempo esgotado!", width / 2, height / 2);
    noLoop(); // Para o jogo
    return;
  }

  // Árvores
  for (let pos of treePositions) {
    drawTree(pos.x, pos.y);
  }

  // Movimento
  if (keyIsDown(LEFT_ARROW)) farmerX -= farmerSpeed;
  if (keyIsDown(RIGHT_ARROW)) farmerX += farmerSpeed;
  if (keyIsDown(UP_ARROW)) farmerY -= farmerSpeed;
  if (keyIsDown(DOWN_ARROW)) farmerY += farmerSpeed;

  farmerX = constrain(farmerX, 0, width);
  farmerY = constrain(farmerY, 0, height - 60);

  drawFarmer(farmerX, farmerY);

  // Maçãs
  for (let i = apples.length - 1; i >= 0; i--) {
    let apple = apples[i];
    drawApple(apple.x, apple.y);

    if (dist(farmerX, farmerY, apple.x, apple.y) < 25) {
      apples.splice(i, 1);
      spawnApple();
    }
  }
}

function drawTree(x, y) {
  fill(139, 69, 19);
  rect(x - 10, y, 20, 50);
  fill(34, 139, 34);
  ellipse(x, y - 20, 50, 50);
}

function drawFarmer(x, y) {
  fill(255, 100, 100);
  rect(x - 15, y, 30, 60);
  fill(255, 228, 196);
  ellipse(x, y - 20, 30, 30);
  line(x - 15, y + 10, x - 30, y + 20);
  line(x + 15, y + 10, x + 30, y + 20);
  fill(139, 69, 19);
  arc(x, y - 35, 35, 20, PI, 0, CHORD);
}

function drawApple(x, y) {
  fill(255, 0, 0);
  ellipse(x, y, 20, 20);
}

function spawnApple() {
  let t = random(treePositions);
  apples.push({
    x: t.x,
    y: t.y - 40
  });
}
